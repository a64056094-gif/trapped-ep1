import asyncio
import json
import os
import edge_tts

SCRIPT_TEXT = (
    "Just a normal night at the movies. "
    "Until the screen went black. "
    "And something landed outside. "
    "They were inside. And they were hunting. "
    "One vent. One chance. "
    "Episode 1. Can he survive the night?"
)

async def main():
    os.makedirs("public", exist_ok=True)
    communicate = edge_tts.Communicate(SCRIPT_TEXT, voice="en-US-ChristopherNeural", rate="-5%")
    await communicate.save("public/voiceover.mp3")
    print("Saved public/voiceover.mp3")

    try:
        from faster_whisper import WhisperModel
        model = WhisperModel("base", device="auto")
        segments, _ = model.transcribe("public/voiceover.mp3", word_timestamps=True)
        words = []
        for seg in segments:
            for w in seg.words:
                words.append({"word": w.word.strip(), "start": round(w.start, 3), "end": round(w.end, 3)})
        with open("public/words.json", "w", encoding="utf-8") as f:
            json.dump(words, f, indent=2)
        print(f"Saved public/words.json ({len(words)} words)")
    except ImportError:
        print("faster-whisper not installed; skipping words.json (pip install faster-whisper)")

if __name__ == "__main__":
    asyncio.run(main())
