import os
import subprocess

os.makedirs("out/stills", exist_ok=True)
video_path = "out/trapped_ep1.mp4"

if not os.path.exists(video_path):
    print("Run `npm run render` first to generate out/trapped_ep1.mp4")
    raise SystemExit(1)

timestamps = [2, 6, 10, 16, 22, 27]
for idx, ts in enumerate(timestamps, 1):
    subprocess.run([
        "ffmpeg", "-y", "-ss", str(ts), "-i", video_path,
        "-frames:v", "1", f"out/stills/scene_{idx}.jpg"
    ], check=True)

subprocess.run([
    "ffmpeg", "-y", "-i", "out/stills/scene_%d.jpg",
    "-filter_complex", "tile=3x2", "out/qa_sheet.jpg"
], check=True)
print("QA contact sheet saved to out/qa_sheet.jpg")
