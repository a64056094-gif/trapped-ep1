import React, { useMemo } from 'react';
import * as THREE from 'three';

interface Stickman2DProps {
  pose: 'sit' | 'scared' | 'hide' | 'run';
  t: number;
  position: [number, number, number];
  scale?: number;
}

export const Stickman2D: React.FC<Stickman2DProps> = ({ pose, t, position, scale = 1 }) => {
  const texture = useMemo(() => {
    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 320;
    const c = canvas.getContext('2d')!;
    c.translate(128, 285);
    c.lineCap = 'round';
    c.lineJoin = 'round';

    const drawLine = (x1: number, y1: number, x2: number, y2: number, w: number) => {
      c.strokeStyle = '#090d16';
      c.lineWidth = w + 6;
      c.beginPath(); c.moveTo(x1, y1); c.lineTo(x2, y2); c.stroke();
      c.strokeStyle = '#f8fafc';
      c.lineWidth = w;
      c.beginPath(); c.moveTo(x1, y1); c.lineTo(x2, y2); c.stroke();
    };

    const crouchY = pose === 'hide' ? 52 : 0;
    const stride = pose === 'run' ? Math.sin(t * 16) * 38 : 0;
    const bob = pose === 'run' ? Math.abs(Math.sin(t * 16)) * 10 : 0;

    if (pose === 'sit') {
      drawLine(0, -70, 32, -66, 12);
      drawLine(32, -66, 36, -15, 12);
    } else if (pose === 'hide') {
      drawLine(-12, -32, -26, -4, 12);
      drawLine(12, -32, 26, -4, 12);
    } else {
      drawLine(0, -75 - bob, -stride, -4, 12);
      drawLine(0, -75 - bob, stride, -4, 12);
    }

    drawLine(0, -145 + crouchY - bob, 0, -72 + crouchY - bob, 13);

    if (pose === 'sit') {
      const chew = Math.sin(t * 5) * 18;
      drawLine(0, -130, 34, -142 - chew, 11);
    } else if (pose === 'hide') {
      drawLine(0, -82, -16, -108, 11);
      drawLine(0, -82, 16, -108, 11);
    } else {
      drawLine(0, -130 - bob, stride * 0.8, -95 - bob, 11);
      drawLine(0, -130 - bob, -stride * 0.8, -95 - bob, 11);
    }

    const hy = -182 + crouchY - bob;
    c.fillStyle = '#f8fafc';
    c.strokeStyle = '#090d16';
    c.lineWidth = 6;
    c.beginPath();
    c.arc(0, hy, 34, 0, Math.PI * 2);
    c.fill();
    c.stroke();

    if (pose === 'scared' || pose === 'hide') {
      [-10, 12].forEach((ex) => {
        c.fillStyle = '#ffffff';
        c.lineWidth = 3;
        c.beginPath(); c.arc(ex, hy - 3, 9, 0, Math.PI * 2); c.fill(); c.stroke();
        c.fillStyle = '#090d16';
        c.beginPath(); c.arc(ex, hy - 3, 3.5, 0, Math.PI * 2); c.fill();
      });
    } else {
      c.fillStyle = '#090d16';
      c.beginPath(); c.arc(-6, hy - 3, 4.2, 0, Math.PI * 2); c.fill();
      c.beginPath(); c.arc(12, hy - 3, 4.2, 0, Math.PI * 2); c.fill();
    }

    const tex = new THREE.CanvasTexture(canvas);
    tex.needsUpdate = true;
    return tex;
  }, [pose, Math.round(t * 30)]);

  return (
    <mesh position={position} scale={[scale, scale, 1]} castShadow>
      <planeGeometry args={[1.45, 1.82]} />
      <meshStandardMaterial map={texture} transparent alphaTest={0.15} side={THREE.DoubleSide} />
    </mesh>
  );
};
