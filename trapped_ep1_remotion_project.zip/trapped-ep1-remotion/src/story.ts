export interface SceneBeat {
  id: number;
  startSec: number;
  endSec: number;
  title: string;
  voiceover: string;
}

export const FPS = 30;
export const DURATION_SEC = 30;

export const SCENES: SceneBeat[] = [
  { id: 1, startSec: 0, endSec: 4, title: 'Dark Theater', voiceover: 'Just a normal night at the movies.' },
  { id: 2, startSec: 4, endSec: 8, title: 'Flicker & Shake', voiceover: 'Until the screen went black.' },
  { id: 3, startSec: 8, endSec: 13, title: 'UFO & Doors Lock', voiceover: 'And something landed outside.' },
  { id: 4, startSec: 13, endSec: 19, title: 'Alien Shadows', voiceover: 'They were inside. And they were hunting.' },
  { id: 5, startSec: 19, endSec: 25, title: 'EXIT & Vent', voiceover: 'One vent. One chance.' },
  { id: 6, startSec: 25, endSec: 30, title: 'Title Zoom-In', voiceover: 'Episode 1. Can he survive the night?' }
];

export const getActiveScene = (t: number): SceneBeat => {
  return SCENES.find((s) => t >= s.startSec && t < s.endSec) || SCENES[SCENES.length - 1];
};
