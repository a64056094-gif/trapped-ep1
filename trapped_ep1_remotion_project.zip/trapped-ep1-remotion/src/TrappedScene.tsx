import React from 'react';
import { AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig } from 'remotion';
import { ThreeCanvas } from '@remotion/three';
import { Stickman2D } from './Stickman2D';
import { getActiveScene } from './story';

const ToonBox: React.FC<{
  args: [number, number, number];
  position: [number, number, number];
  color: string;
}> = ({ args, position, color }) => (
  <mesh position={position} castShadow receiveShadow>
    <boxGeometry args={args} />
    <meshStandardMaterial color={color} roughness={0.78} />
  </mesh>
);

export const TrappedShort: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps, width, height } = useVideoConfig();
  const t = frame / fps;
  const active = getActiveScene(t);

  const words = active.voiceover.split(' ');
  const sceneProg = Math.min(1, Math.max(0, (t - active.startSec) / (active.endSec - active.startSec)));
  const word = words[Math.min(words.length - 1, Math.floor(sceneProg * words.length))];

  const pose =
    active.id === 1 ? 'sit' : active.id === 2 ? 'scared' : active.id === 4 ? 'hide' : 'run';

  const charPos: [number, number, number] =
    active.id <= 2
      ? [0, 1.05, 0.55]
      : active.id === 4
      ? [Math.sin(t * 40) * 0.03, 0.82, 0.95]
      : [
          interpolate(t, [19, 24.5], [-2.0, 1.75], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' }),
          interpolate(t, [22.5, 25], [0.92, 1.95], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' }),
          interpolate(t, [19, 24.5], [0.8, -1.9], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' })
        ];

  const shakeX = active.id === 2 ? Math.sin(t * 50) * 0.12 : 0;

  return (
    <AbsoluteFill style={{ backgroundColor: '#070a14' }}>
      <ThreeCanvas width={width} height={height} shadows camera={{ fov: 46, position: [shakeX, 1.85, 4.4] }}>
        <color attach="background" args={['#0b1022']} />
        <fogExp2 attach="fog" args={['#0b1022', 0.032]} />
        <hemisphereLight args={['#93c5fd', '#1e1b4b', 0.8]} />
        <directionalLight position={[4, 9, 6]} intensity={1.2} color="#ffedd5" castShadow />

        {/* Floor */}
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[24, 24]} />
          <meshStandardMaterial color="#111827" roughness={0.85} />
        </mesh>

        {/* Scenes 1, 2, 4: Theater */}
        {(active.id <= 2 || active.id === 4) && (
          <group>
            <ToonBox args={[14, 7, 0.4]} position={[0, 3.5, -6]} color="#161f38" />
            <mesh position={[0, 3.8, -5.75]}>
              <planeGeometry args={[7.8, 4.2]} />
              <meshBasicMaterial color={active.id === 1 ? '#1d4ed8' : '#020617'} />
            </mesh>
            {[-2, -1, 0, 1, 2].map((col) => (
              <ToonBox key={col} args={[1.1, 1.3, 0.9]} position={[col * 1.45, 0.65, 0.2]} color="#263452" />
            ))}
          </group>
        )}

        {/* Scene 3: Exterior UFO */}
        {active.id === 3 && (
          <group>
            <ToonBox args={[3.8, 5.2, 3.2]} position={[-1.8, 2.6, -2.5]} color="#26293e" />
            <mesh position={[1.4, interpolate(t, [8, 12], [5.5, 3.6], { extrapolateRight: 'clamp' }), -1.5]}>
              <cylinderGeometry args={[1.5, 1.8, 0.45, 20]} />
              <meshStandardMaterial color="#475569" />
            </mesh>
            <pointLight position={[1.4, 2.8, -1.5]} color="#ef4444" intensity={4} distance={14} />
          </group>
        )}

        {/* Scene 5: Hallway & Vent */}
        {active.id === 5 && (
          <group>
            <ToonBox args={[14, 7, 0.4]} position={[0, 3.5, -2.5]} color="#162038" />
            <ToonBox args={[1.4, 0.7, 0.2]} position={[1.8, 3.8, -2.2]} color="#10b981" />
            <ToonBox args={[1.4, 1.3, 0.25]} position={[1.8, 2.1, -2.2]} color="#334155" />
          </group>
        )}

        {active.id !== 3 && active.id !== 6 && <Stickman2D pose={pose} t={t} position={charPos} />}
      </ThreeCanvas>

      {/* Scene 6 Title Slam */}
      {active.id === 6 && (
        <AbsoluteFill style={{ justifyContent: 'center', alignItems: 'center', background: 'rgba(3,3,6,0.92)' }}>
          <div
            style={{
              color: '#dc2626',
              fontSize: 132,
              fontWeight: 900,
              transform: `scale(${interpolate(t, [25, 28], [0.65, 1.15], { extrapolateRight: 'clamp' })})`
            }}
          >
            TRAPPED
          </div>
          <div style={{ color: '#fca5a5', fontSize: 34, fontWeight: 700, letterSpacing: 8 }}>EPISODE 1</div>
        </AbsoluteFill>
      )}

      {/* Viral Word-by-Word Caption */}
      <div
        style={{
          position: 'absolute',
          bottom: 240,
          width: '100%',
          textAlign: 'center',
          color: '#ffffff',
          fontSize: 78,
          fontWeight: 900,
          textTransform: 'uppercase',
          textShadow: '-4px -4px 0 #000, 4px -4px 0 #000, -4px 4px 0 #000, 4px 4px 0 #000'
        }}
      >
        {word}
      </div>
    </AbsoluteFill>
  );
};
