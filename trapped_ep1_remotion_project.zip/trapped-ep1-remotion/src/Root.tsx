import React from 'react';
import { Composition } from 'remotion';
import { TrappedShort } from './TrappedScene';

export const RemotionRoot: React.FC = () => {
  return (
    <Composition
      id="TrappedEp1"
      component={TrappedShort}
      durationInFrames={900}
      fps={30}
      width={1080}
      height={1920}
    />
  );
};
