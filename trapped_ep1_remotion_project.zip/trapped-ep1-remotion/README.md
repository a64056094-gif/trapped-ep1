# TRAPPED — Episode 1 (Remotion + @remotion/three)

## 1. Prerequisites (Free)
- Node.js 18+ & npm
- Python 3.10+ & FFmpeg in PATH

## 2. Setup & Preview
```bash
npm install
npm run studio
```

## 3. Generate Free Voiceover + Word Timings
```bash
pip install edge-tts faster-whisper
python scripts/generate_voice.py
```

## 4. Render 1080x1920 MP4 & Run Python QA
```bash
npm run render
python scripts/qa_frames.py
```
Open `out/qa_sheet.jpg` to inspect all 6 scenes side-by-side!
